<html>
    <head>
        <script type="text/javascript">
            function create_sum(){
                var number1 = document.getElementById("number1").value;
                var number2 = document.getElementById("number2").value;

                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function(){ document.getElementById("addition").innerHTML = xmlhttp.responseText;
                }
                
                xmlhttp.open("GET","addition.php?number1="+number1+"&number2="+number2,true);
                xmlhttp.send();
            }
            
        </script>
    </head>
    <body>
        <label>Number 1</label>
        <input type="text" id="number1" /><br/>

        <label>Number 2</label>
        <input type="text" id="number2" /><br/>

        <p id="addition"></p>

        <button id="click" onclick="create_sum();">Sum</button>
    </body>
</html>