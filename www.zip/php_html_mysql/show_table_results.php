<?php include 'config.php'; ?>
<html>
    <head>
        <title>HTML Example</title>
        <link href="style.css" rel="stylesheet" />
    </head>
    <body>
        <table class="table_class" width="100%" >
            <tr>
                <th>Student Id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Mobile</th>
            </tr>
        <?php
            $query = "SELECT * FROM student";
            $result = $conn->query($query);

            if($conn->error){

            } else {
                while($row = $result->fetch_assoc()){

        ?>
            <tr>
                <?php if($row['student_id'] == 1): ?>
                    <td><?php echo $row['student_id']; ?></td>
                    <td><?php echo $row['firstname']; ?></td>
                    <td><?php echo $row['lastname']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['mobile_number']; ?></td>
                <?php endif; ?>
            </tr>

        <?php
                }
            }
        ?>
        </table>
    </body>
</html>