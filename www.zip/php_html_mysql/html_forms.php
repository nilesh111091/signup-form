<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style>
            #myform {
                width: 100%;
                background: #e1e1e1;
                padding: 20px 20px 20px 20px;
                margin: 20px 20px 20px 20px;
                border: 10px dashed #ccc;
            }
            #myform label {
                width: 20%;   
                display: inline-block;
            }
            #myform input{
                width: 70%;
                display: inline-block;
            }
        </style>
    </head>
    <body>
        <h2>HTML Form</h2>
        <form id="myform" class="myform">
            
            <label>First Name</label>
            <input type="text" name="first_name" value="Nilesh" class="input_field"/>
            
            <br/>

            <label>Last Name</label>
            <input type="text" name="last_name" value="K" class="input_field"/>
            <br/>

            <label>Branch</label>
            <input type="text" name="branch" value="MCA" class="input_field"/>
            <br/>

            <label>Semester</label>
            <input type="radio" name="semester" value="sem1" /> Semester 1 <br/>
            <input type="radio" name="semester" value="sem2" /> Semester 2 <br/>
            <input type="radio" name="semester" value="sem3" /> Semester 3 <br/>
            <input type="radio" name="semester" value="sem4" /> Semester 4 <br/>
            <input type="radio" name="semester" value="sem5" /> Semester 5 <br/>
            <input type="radio" name="semester" value="sem6" /> Semester 6 <br/>

            <label>Address</label>
            <textarea name="address" class="textarea"></textarea>
            <input type="submit" name="submit" class="btn btn-submit" />
        </form>

        <!-- <div id="myform">
            <p>Text</p>
        </div> -->
    </body>
</html>