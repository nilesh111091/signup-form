<?php
include 'config.php';
$number1 = $_GET['number1'];
$number2 = $_GET['number2'];

$sql = "INSERT INTO newtable (number1, number2) VALUES('$number1','$number2')";
$conn->query($sql);

if($conn->error){
    echo 'Could not insert the record'.$conn->error;
} else {
    echo "Record Inserted Successfully";
}
?>