<?php
include 'config.php';
if(!isset($_SESSION['logged_in']) && $_SESSION['logged_in'] != true){
    header("location: customer_login.php");
}
?>

<html>
    <head></head>
    <body>
        Welcome, <?php echo $_SESSION['firstname'] . ' ' . $_SESSION['lastname']; ?>
        <a href="logout.php">Logout</a>
    </body>
</html>