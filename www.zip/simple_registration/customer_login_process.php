<?php
include 'config.php';
$email = $_POST['customer_email'];
$password = $_POST['password'];

$sql_query = "SELECT * FROM customer WHERE customer_email = '$email' AND customer_password = '$password'";
$result = $conn->query($sql_query);
$customer_result = $result->fetch_assoc();

if(empty($customer_result)){
    //echo 'No Matching Records Found, Login Failed';
    header("location: customer_login.php?msg=No Matching Records Found, Login Failed");
} else {
    $_SESSION['logged_in'] = true;
    $_SESSION['email'] = $customer_result['customer_email'];
    $_SESSION['firstname'] = $customer_result['customer_firstname'];
    $_SESSION['lastname'] = $customer_result['customer_lastname'];

    header("location: dashboard.php");
}
?>