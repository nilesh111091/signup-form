<?php
include 'config.php';
$email = $_POST['customer_email'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$password = $_POST['password'];

$query = "INSERT INTO customer(customer_email, customer_firstname, customer_lastname, customer_password, customer_created_date) VALUES('$email', '$firstname', '$lastname', '$password', NOW())";
$conn->query($query);

if($conn->error){
    echo $conn->error;
} else {
    echo "Customer Registered Successfully";
}
?>