<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database_name = "sou_customer_db";


$conn = mysqli_connect($servername, $username, $password, $database_name);

if($conn->connect_error){
    die($conn->connect_error);
} 

?>