<?php
// Student Registration
/*
    student_id
    firstname
    lastname
    mobile_number
    email
    address
    branch
    semester
    created_date
    updated_date
*/

$servername = "localhost";
$username = "root";
$password = "";
$database_name = 'sou_practice_db';


$conn = mysqli_connect($servername, $username, $password,$database_name);

if($conn->connect_error){
    die($conn->connect_error);
} else {
    echo 'MySql Database Connection Successful';
}

$sql = "INSERT INTO student (student_id,firstname, lastname, mobile_number)";

?>