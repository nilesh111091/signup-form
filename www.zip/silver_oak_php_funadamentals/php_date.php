<?php
date_default_timezone_set('Asia/Kolkata');
$time = date('h:i:s');
$date=date_create("15-05-2023");
echo date_format($date,"d/m/Y");

$date1=date_create("2022-05-16");
$date2=date_create("2023-05-30");
$diff=date_diff($date1,$date2);
echo '<pre>';
print_r($diff);

echo 'mktime function<br/>';
echo date("l", mktime(0,0,0,12,30,2023));

?>