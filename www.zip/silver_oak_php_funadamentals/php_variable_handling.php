<?php
$abc = "";
if(empty($abc)){
    echo 'Yes this is empty variable';
}

$abc = "25.56fsdkfdljj"; 
echo '<br/>';
$bca = 24;
echo floatval($abc) + intval($abc);
echo floatval($bca) . '<br/>';
echo intval($abc);

$abc = 2;
$bcd = 4;
$xyz = 98;
if(isset($abc) && isset($xyz)){
    echo 'Both variables are set';
} else {
    echo '<br/>';
    echo (isset($abc) ? 'abc is set' : 'abc is not set');
    echo '<br/>';
    echo (isset($xyz) ? 'xyz is set' : 'xyz is not set');
}

// Unset the variable 
$array = array(
    "Blue" => "Ocean",
    "Orange"=> "Cap",
    "Black" => "Crow"
);
unset($abc);
echo '<pre>';
print_r($abc);
?>