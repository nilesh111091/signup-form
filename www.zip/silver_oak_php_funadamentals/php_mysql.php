<?php
$servername = "localhost";
$username = "root";
$password = "";


$conn = mysqli_connect($servername, $username, $password);

if($conn->connect_error){
    die($conn->connect_error);
} else {
    echo 'MySql Connection Successful';
}

$result = $conn->query("CREATE DATABASE sou_practices");

if($result){
    echo '<br/>';
    echo 'Database Created Successfully';
} else {
    echo 'Database Can not Created';
}
?>