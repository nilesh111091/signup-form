<?php

$array_with_keys = array(
            "Key1" => 10,
            "Key2" => 20,
            "Key3" => 5,
        );

$array_without_keys = array("Value1","Value2","Value3");

// Array using brackets

$array_brackets = ["value1","value2","value3"];

$multidimensional_array = array(
                            "first" => array(
                                "first_first"=>20
                            ),
                            "second" => array(
                                "second_first"=>20,
                                "second_second" => array(
                                    "second_second_first" => "sub sub array"    
                                )
                            )
                        );



$array_with_keys["key4"] = "value4";
$array_without_keys[0] = "45";
$array_without_keys[] = "456";

// print_r($array_with_keys);
// print_r($array_without_keys);
// print_r($array_brackets);

// print_r($multidimensional_array);


// Sorting

//$sort = sort($array_with_keys);
$asort = asort($array_without_keys);
//rsort($array_with_keys);
ksort($array_with_keys);
krsort($array_with_keys);

// print_r($array_with_keys);
// print_r($array_without_keys);

?>