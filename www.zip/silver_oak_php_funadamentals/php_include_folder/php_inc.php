<?php
function myfunction(){
    echo 123;
}
?>