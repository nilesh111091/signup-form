<?php
//echo readfile('reading_file_php.txt','r');

$file = fopen('mynewfile.txt','w');
$content = "This is my new file content";
fprintf($file, $content);
echo readfile('mynewfile.txt','r');
?>