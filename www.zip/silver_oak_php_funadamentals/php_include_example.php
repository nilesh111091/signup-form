<?php
require_once('php_constants.php');

echo 'PHP INCLUDE FILE NAME' . '<br/>';
echo TESTING_GLOBAL;
echo '<pre>';
print_r($global_array);
echo '<br/>';

?>