<?php
// switch keyword

$keyword = "not";

switch( $keyword ){
    case "yes":
        echo 'Its Yes';
        break;
    case "no":
        echo "It's no";
        break;
    default:
        echo "Its not yes or not no";
}
?>