<?php
$array = array(
    "Login",
    "Sign up",
    "Sign out"
);
$chkarray = "text";

if(is_array($array)){
    echo 'This is an array';
}


echo '<br/>in_array example<br/>';
$inarray_var = array(
                "Blue",
                "Green",
                "Red"
            );
if(in_array("Black",$inarray_var) == true){
    echo 'Value Exist';
}

// NOT Operator
echo '<br/>NOT Operator example<br/>';
$x = 10;
$y = "10";
//$z = (int)$y;

if($x === (int)$y){
    echo '$x is equal to $y';
}

echo '<br/>Merged Array Example<br/>';
$array_one = array(
    "January","February","March","April"
);
$array_two = array(
    "Start Day"=>"Sunday","Monday","Tuesday"
);

$merged_array = array_merge($array_one, $array_two);
echo '<pre>';
print_r($merged_array);


echo '<br/>Array_keys Array Example<br/>';
$keyArray = array(
    "First Month" => "January",
    "Second Month" => "February",
    "Third Month" => "March"
);

$keys = array_keys($keyArray);
$values = array_values($keyArray);
echo '<pre>';
print_r($keys);
print_r($values);

var_dump(array_key_exists("First Months", $keyArray));

echo '<br/>Array Shift Example<br/>';
$monthdays = array(
    "month" => array(
        "January",
        "Feb",
        "March",
        "April"
    ),
    "days" => array(
        "Sunday",
        "Monday",
        "Tuesday"
    )
);
$shifted = array_shift($monthdays);
echo '<pre>';
print_r($shifted);
print_r($monthdays);

$daysarray = array(
    "Sunday",
    "Monday",
    "Tuesday"
);

$daysshift = array_shift($daysarray);
print_r($daysshift);
print_r($daysarray);

echo '<br/>Array POP Example<br/>';
$monthdays = array(
    "month" => array(
        "January",
        "Feb",
        "March",
        "April"
    ),
    "days" => array(
        "Sunday",
        "Monday",
        "Tuesday"
    )
);
$poparray = array_pop($monthdays);
echo '<pre>';
print_r($poparray);
print_r($monthdays);

echo '<br/>Array push Example<br/>';
$monthdays = array(
    "month" => array(
        "January",
        "Feb",
        "March",
        "April"
    ),
    "days" => array(
        "Sunday",
        "Monday",
        "Tuesday"
    )
);
array_push($monthdays, "Array Push Example");
print_r($monthdays);

echo '<br/>Array Unique Example<br/>';
$month = array(
    "January",
    "Feb",
    "March",
    "April",
    "April",
    "May",
    "Feb"
);

print_r(array_unique($month));

?>