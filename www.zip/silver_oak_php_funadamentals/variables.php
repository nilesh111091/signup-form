<?php
    $silver_oak = "Double Quoted String";
    $integer_variable = 20;
    $string_example = 'single quoted string' . 'xyz';
    
    // Comment

    /* $abc = "Commented String";
    $def = "Commented String"; */

    $x = 20;
    $y = 50;

    $sum = $x + $y;
    $substract = $x - $y;
    $multiply = $sum * $substract;
    $division1 = $y / $x;
    $division2 = $x / $y;
    $division3 = (float)($x/$y);

    echo $silver_oak . '<br/>'; 

    echo "$silver_oak";

    echo $integer_variable . '<br/>';

    var_dump($string_example);
    var_dump($sum);
    var_dump($substract);

    echo '<br/>';
    print $multiply;
    print $division1;

    echo '<pre>';
    var_dump($division2);
    echo '</pre>';

    echo $division3;


?>