<?php
// array_count_values

$array = array(45,95,80,95,10,10,20,20);
print_r(array_count_values($array));echo '<br/>';

// array_key_exists

$array = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Red"=> "Apple"
);
if(array_key_exists("BlueG",$array)){
    echo 'Key Exists <br/>';
} else {
    echo "Key Does not exist";
}

// array_keys
$array = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Red"=> "Apple"
);
echo '<pre>';
print_r(array_keys($array));echo '<br/>';
// array_merge

$array1 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Red"=> "Apple"
);

$array2 = array(
    "day1"=>"Sunday",
    "day2" => "Monday",
    "day3"=> "Tuesday"
);
echo '<pre>Merge';
print_r(array_merge($array1,$array2));
// array_rand

$array = array(34,45,67,78,98);
echo '<pre>';
print_r(array_rand($array,2));
// array_replace

$array = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Red"=> "Apple"
);
$array2 = array(
    "Blue" => "Horse"
);
print_r(array_replace($array,$array2));
// array_reverse
$array = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Red"=> "Apple"
);
$array = array(34,45,67,78,98);
print_r(array_reverse($array));
// array_search
$array = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Red"=> "Apple"
);
$array = array(34,45,67,78,98);

print_r(array_search(78,$array));echo '<br/>';

// array_shift
$array = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Red"=> "Apple"
);
print_r(array_shift($array));
print_r($array);
// array_diff
$array1 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Red"=> "Apple"
);
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch"
);
print_r(array_diff($array1,$array2));

// shuffle
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch"
);
shuffle($array2);
print_r($array2);

// list
list($a, $b, $c) = array(30,25,10,50);
echo "a variable " . $a . '<br/>';
echo "b variable " . $b . '<br/>';
echo "c variable " . $c . '<br/>';
// array_map
$array = array(34,45,67,78,98);


function myfunction($values){
    return $values * $values;
}

$array = array(34,45,67,78,98);
print_r(array_map('myfunction',$array));

// array_walk
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch"
);

function mywalkfunction($value, $key){
    echo "$key is equal " .$value ."<br/>";
}
array_walk($array2,'mywalkfunction');


// array_unique
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch",
    "Angle" => "Ocean"
);
$array = array(32,67,67,65,43,67);
print_r(array_unique($array));
// array_push
array_push($array,45);
print_r($array);
// array_pop
array_pop($array);
print_r($array);
// in_array
if(in_array("Bridge",$array2) == true){
    echo 'Available';
}
// count
$count_of_array = count($array2);
echo '<br/>' . $count_of_array ;

// array_values
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch",
    "Angle" => "Ocean"
);
print_r(array_values($array2));
// ksort
echo '<br/>';
echo "ksort Example:";
echo '<br/>';
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch",
    "Angle" => "Ocean"
);
ksort($array2);
print_r($array2);

//asort
echo '<br/>';
echo "asort Example:";
echo '<br/>';
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch",
    "Angle" => "Ocean"
);
asort($array2);
print_r($array2);
// krsort
echo '<br/>';
echo "krsort Example:";
echo '<br/>';
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch",
    "Angle" => "Ocean"
);
krsort($array2);
print_r($array2);
echo '<br/>';
echo "sort Example:";
echo '<br/>';
// sort
$array2 = array(
    "Blue"=>"Ocean",
    "Green" => "Grass",
    "Square" => "Bridge",
    "Triangle"=> "Pitch",
    "Angle" => "Ocean"
);
sort($array2);
print_r($array2);
?>