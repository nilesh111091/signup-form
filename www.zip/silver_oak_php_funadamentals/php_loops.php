<?php

//FOR Loop
echo 'FOR LOOP<br/>';
for($i=0;$i<10;$i++){
    echo $i . '<br/>';
}

// WHILE Loop
echo '<br/>';
echo 'WHILE LOOP<br/>';
$j = 0;
while($j<=10){
    echo $j . '<br/>';;
    $j++;
}

echo 'DO WHILE LOOP<br/>';
// DO WHILE LOOP
echo '<br/>';
$k = 0;
do {
    echo $k . '<br/>';;
    $k++;
} while($k < 10);

echo 'FOREACH LOOP<br/>';
// FOREACH LOOP
echo '<br/>';
$array = array("We","Are","Learning","PHP");
foreach($array as $value){
    echo $value . ' ';
}


$multidimensional_array = array(
    "fruits" => array("mangoes","apple","pineapple"),
    "EMP_IDS" => array("EMPID0001","EMPID0002","EMPID0003","EMPID0004"),
    "food_products" => array("Burger","Sandwitch","Vadapav"),
    "milk_products" => array("cheese","butter","curd")    
);

echo '<pre>';
print_r($multidimensional_array);

echo 'Foreach with multidimensional array <br/>';
foreach($multidimensional_array as $key=>$array){
    foreach($array as $subarrayvalue){
        echo $subarrayvalue . ' | ';
    }
    echo '<br/>';
}
?>