<?php
echo '<br/>addslashes example';
$text = "Rakesh's lab";
$result = addslashes($text);
echo $result;

echo '<br/>explode example';
$text = "Rakesh,Ramesh,Suresh,Himesh";
$result = explode(',', $text);
echo '<pre>';
print_r($result);

echo '<br/>implode example';
$implode_result = implode('-',$result);
echo $implode_result;

echo '<br/>htmlentities example<br/>';
$htmlentity_string = "&lt;a&gt;";
htmlentities($htmlentity_string);
echo $htmlentity_string;

echo '<br/>html entity decode example<br/>';
$htmlentity_string = "&lt;a&gt;";

html_entity_decode($htmlentity_string);
echo $htmlentity_string;

echo '<br/>lcfirst example<br/>';
$text = "THIS IS NICE TEXT";
echo lcfirst($text);

echo '<br/>ucfirst example<br/>';
$text = "this is nice text";
echo ucfirst($text);

echo '<br/>ucwords example<br/>';
$text = "this is nice text";
echo ucwords($text);

echo '<br/>md5 example<br/>';
$password = "Test@123#";
echo md5($password);

echo '<br/>sha1 example<br/>';
$text = "Test@123#";
echo sha1($text);

echo '<br/>ltrim example<br/>';
$text = "     Test@123#";
echo ltrim($text);

echo '<br/>rtrim example<br/>';
$text = "Test@123#&nbsp;  &nbsp;";
echo rtrim($text);

echo '<br/>trim example<br/>';
$text = "     Test@123#   ";
echo trim($text,);

echo '<br/>str_replace example<br/>';
$replace_text = "Google";
$text = "Good Morning!";
echo str_replace('Good',$replace_text,$text);

echo '<br/>str_word_count example<br/>';
$text = "A commonly used entity in HTML is the non-breaking space: . &nbsp; A non-breaking space is a space that will not break into a new line.";

var_dump(strpos($text, 'entity'));
var_dump(stripos($text, 'entity'));

echo '<pre>';
echo strlen($text);

$f = fopen("mytext.txt","w");
$text = "welcome to computer lab";
$printtofile = fprintf($f, $text);

echo '<br/><br/>number_format example<br/>';
$amount = 10000;
$number_format = number_format($amount,3);
echo $number_format;


?>