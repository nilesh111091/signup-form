<?php

//preg_match (string $pattern, string $subject, array $matches, int $flags, int $offset)

$website = "PHP is Good language.";
$regex = "/php/";
if(preg_match($regex,$website) == true){
    echo 'found the PHP string';
} else {
    echo 'Match not found';
}

echo "<br><br>";
$boundary_string = "This is my website for the web new website";
$regex = '/web/';
var_dump(preg_match($regex, $boundary_string));



 $email = "asd/sdff@asdf.com"; 
 $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/'; 
 $email = (preg_match($regex, $email))?$email:"invalid email";
 echo $email;


echo "<br><br>";
echo 'preg_match_all example';
$regex = '/web/';
print_r(preg_match_all($regex, $boundary_string));
echo "<br><br>";


echo "<br><br>";
echo 'preg_replace example';
$regex = '/web/';
$test_string = "This is my website for the web new website";
echo "<br><br>";
echo preg_replace($regex,'theme',$test_string);

?>