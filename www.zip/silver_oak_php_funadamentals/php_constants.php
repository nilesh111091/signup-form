<?php
define("TESTING_GLOBAL","xyz BUtter Panner");

// GLOBAL ARRAY EXAMPLE
$global_array = array(
    "fruits" => array("mangoes","apple","pineapple"),
    "EMP_IDS" => array("EMPID0001","EMPID0002","EMPID0003","EMPID0004"),
    "food_products" => array("Burger","Sandwitch","Vadapav"),
    "milk_products" => array("cheese","butter","curd")    
);

$x = 10;
$y = 20;

?>