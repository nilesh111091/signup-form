
<?php
$x = 67;
$single_quote = 'this is single quoted string, $x';

$double_quote = "this is double quoted string, $x";

echo $single_quote;
echo '<br/>';
echo $double_quote;


// How to use in HTML TAGS
echo '<br/>Single Quote HTML';
$single_quote_html = '<a href="https://www.website.com">www.website.com</a>';
echo $single_quote_html;

echo '<br/>Double Quote HTML';
$double_quote_html = "<a href='https://www.website.com'>www.website.com</a>";
echo $double_quote_html;

$x = 2;
echo <<<demo
<style>
h2 {
    color: blue;
    font-weight: 300;
}
</style>
<div class=''>
    <h2>My Header Heading</h2>
    <div class=''>
    <p>My Coontent $x</p>
    </div>
</div>
demo;


echo <<<'demo'
<style>
h2 {
    color: blue;
    font-weight: 300;
}
</style>
<div class=''>
    <h2>My Header Heading</h2>
    <div class=''>
    <p>My Coontent $x</p>
    </div>
</div>
demo;
?>