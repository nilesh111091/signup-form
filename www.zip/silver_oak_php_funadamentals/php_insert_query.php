<?php
$servername = "localhost";
$username = "root";
$password = "";
$database_name = 'sou_practice_db';


$conn = mysqli_connect($servername, $username, $password,$database_name);

if($conn->connect_error){
    die($conn->connect_error);
} else {
    echo 'MySql Database Connection Successful';
}


$query = "INSERT INTO student(firstname, lastname, mobile_number, email, address, branch, semester, created_date, updated_date) VALUES('Nilesh', 'Brahmkshatriya', '0323456789', 'abcd@gmail.com', 'Sanand', 'IT', 'sem3', NOW(), NOW());";
$query .= "INSERT INTO student(firstname, lastname, mobile_number, email, address, branch, semester, created_date, updated_date) VALUES('Nilesh', 'Brahmkshatriya', '98237947', 'abcde@gmail.com', 'Sanand', 'IT', 'sem3', NOW(), NOW());";

$result = $conn->multi_query($query);

if($conn->error){
    echo $conn->error;
} else {
    echo 'Record inserted successfully';
}
?>