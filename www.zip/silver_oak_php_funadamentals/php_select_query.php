<?php
$servername = "localhost";
$username = "root";
$password = "";
$database_name = 'sou_practice_db';


$conn = mysqli_connect($servername, $username, $password,$database_name);

if($conn->connect_error){
    die($conn->connect_error);
} else {
    echo 'MySql Database Connection Successful';
}

$query = "SELECT * FROM student";
$result = $conn->query($query);

if($conn->error){
    echo $conn_error;
} else {
    echo '<br/>';
    while($row = $result->fetch_assoc()){
        echo '<pre>';
        print_r($row);
        echo "Hi" . $row['firstname'] . 
        " " .$row['lastname'] . ', ';
        echo implode(' | ', $row) . '<br/>';
    }
}