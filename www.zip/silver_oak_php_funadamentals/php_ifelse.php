<?php
$x = 30;
$y = 40;
$z = 60;
$d = 50;
echo $min = min(20,10,5);
echo max($x,$y,$z,$d);

if($x < $y){
    echo "$x is Less Than $y";
} else {
    echo "$x is not Less Than $y";
}

/* if( condition ){
     
} else {

}
 */


if($z > $y){
    echo "$z is Greater Than $y";
} else {
    echo "$z is not Greater Than $y";
}


if($x < $y && $z > $y){
    echo "$x is Less Than $y AND $z is Greater Than $y";
} else {
    echo 'Did not match';
}

//Ternary Operator

echo (($y < $z) ? $y . ' ' . $z : 'print something');

if($y < $z OR $d > $y){
    echo "Any one condition is true";
}
exit;

if($x > $y){
    echo "$x is Greater Than $y";
} elseif($z > $y){
    echo "$z is Greater Than $y";
} elseif($d < $x){
    echo "$d is Less Than $x";
}

?>