<?php
$servername = "localhost";
$username = "root";
$password = "";
$database_name = 'sou_practices';


$conn = mysqli_connect($servername, $username, $password,$database_name);

if($conn->connect_error){
    die($conn->connect_error);
} else {
    echo 'MySql Database Connection Successful';
}


?>